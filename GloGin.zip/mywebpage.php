<?php
require_once('gLogin.php');
$mylogin = new ghostLogin();
$mylogin->magicVar();


/*************WRITE YOUR CODE HERE*************/
//Uncomment to destroy active session on refresh page
unset($_SESSION[$mylogin->getSessionName()]);

//code example  - write your code 
$html = file_get_contents('http://yahoo.es');
echo $html;

/***********************************************/
?>


